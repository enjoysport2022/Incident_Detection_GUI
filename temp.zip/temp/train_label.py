import pandas as pd

f20140903 = pd.read_csv('./20140903.csv')
f20140912 = pd.read_csv('./20140912.csv')
f20140913 = pd.read_csv('./20140913.csv')
f20140920 = pd.read_csv('./20140920.csv')
f20140921 = pd.read_csv('./20140921.csv')
f20140922 = pd.read_csv('./20140922.csv')
f20140924 = pd.read_csv('./20140924.csv')
f20140926 = pd.read_csv('./20140926.csv')
f20140927 = pd.read_csv('./20140927.csv')
f20140928 = pd.read_csv('./20140928.csv')
f20141003 = pd.read_csv('./20141003.csv')
f20141006 = pd.read_csv('./20141006.csv')
f20141007 = pd.read_csv('./20141007.csv')
f20141008 = pd.read_csv('./20141008.csv')
f20141017 = pd.read_csv('./20141017.csv')
f20141019 = pd.read_csv('./20141019.csv')
f20141023 = pd.read_csv('./20141023.csv')
f20141025 = pd.read_csv('./20141025.csv')
f20141027 = pd.read_csv('./20141027.csv')
f20141028 = pd.read_csv('./20141028.csv')
f20141104 = pd.read_csv('./20141104.csv')
f20141106 = pd.read_csv('./20141027.csv')
f20141113 = pd.read_csv('./20141113.csv')
f20141114 = pd.read_csv('./20141114.csv')
f20141116 = pd.read_csv('./20141116.csv')
f20141220 = pd.read_csv('./20141220.csv')
f20141227 = pd.read_csv('./20141227.csv')

f20140903['label'] = [0,0,0,0,0
                     ,0,0,0,0,0
                     ,0,0,0,0,0
                     ,0,0,0,0,1]

# print(f20140903)

f20140912['label'] = f20140903['label']
f20140913['label'] = f20140903['label']
f20140920['label'] = f20140903['label']
f20140921['label'] = f20140903['label']
f20140922['label'] = f20140903['label']
f20140924['label'] = f20140903['label']
f20140926['label'] = f20140903['label']
f20140927['label'] = f20140903['label']
f20140928['label'] = f20140903['label']
f20141003['label'] = f20140903['label']
f20141006['label'] = f20140903['label']
f20141007['label'] = f20140903['label']
f20141008['label'] = f20140903['label']
f20141017['label'] = f20140903['label']
f20141019['label'] = f20140903['label']
f20141023['label'] = f20140903['label']
f20141025['label'] = f20140903['label']
f20141027['label'] = f20140903['label']
f20141028['label'] = f20140903['label']
f20141104['label'] = f20140903['label']
f20141106['label'] = f20140903['label']
f20141113['label'] = f20140903['label']
f20141114['label'] = f20140903['label']
f20141116['label'] = f20140903['label']
f20141220['label'] = f20140903['label']
f20141227['label'] = f20140903['label']

train = pd.concat([f20140903,f20140912,f20140913,f20140920,f20140921,f20140922,f20140924,f20140926,f20140927,f20140928
                  ,f20141003,f20141006,f20141007,f20141008,f20141017,f20141019,f20141023,f20141025,f20141027,f20141028
                  ,f20141104,f20141106,f20141113,f20141114,f20141116,f20141220,f20141227])
train.index = range(len(train))
train.to_csv('./train.csv',index=False)
print(train)

